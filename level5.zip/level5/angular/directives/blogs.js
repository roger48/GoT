myApp.directive("specialCard",function(){

       return{
		restrict : "E",
		templateURL : "views/post-card.html",
		controller : function($scope){
			console.log("directive scope");
			console.log($scope.BooksData);

		}
	}
});