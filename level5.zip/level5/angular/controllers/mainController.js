myApp.controller('mainController',['$http','$scope','mainService',function($http,$scope,mainService) {


	$scope.BooksData = [];
	console.log($scope.BooksData);

	$scope.loadBooks = function(){

		mainService.getAllBooks().success(function(response){
			console.log(response.data);
			$scope.BooksData = response.data.data
		}, function errorCallback(response){
			alert("Some Error Occured. Check the Console.")
		});
	}
}]);