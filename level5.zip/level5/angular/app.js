
// first we have to declare the module. note that [] is where we will declare the dependecies later. Right now we are leaving it blank
var myApp = angular.module('blogApp', ['ngRoute']);



myApp.controller('mainController',['$http','$scope',function($http,$scope) {

		   $http.get('https://anapioficeandfire.com/api/books').success(function(data){
			
			$scope.BooksData= data;
			console.log($scope.BooksData);

		});
}]);

myApp.controller('characController',['$http','$scope',function($http,$scope) {

		   $http.get('https://anapioficeandfire.com/api/characters').success(function(data1){
			
			$scope.charData= data1;
			console.log($scope.charData);

		});
}]);

myApp.controller('houseController',['$http','$scope',function($http,$scope) {

		   $http.get('https://anapioficeandfire.com/api/houses').success(function(data2){
			
			$scope.houseData= data2;
			console.log($scope.houseData);

		});
}]);


